BEN GROWTH — PWA

Files:
- index.html: the tracker
- manifest.webmanifest: install/app information
- sw.js: offline support
- icons/: home-screen icons

IMPORTANT:
A PWA must be served from HTTPS (or localhost during development).
Opening index.html directly as a file usually will NOT allow Chrome to install it as a PWA.

Easy hosting:
1. Upload this whole folder to a static HTTPS host.
2. Open the resulting HTTPS website in Chrome on Android.
3. Tap the Chrome menu (⋮).
4. Choose "Install app" or "Add to Home screen".
5. Name it Ben Growth if prompted.

The tracker stores its saved data locally in the browser on the device.
